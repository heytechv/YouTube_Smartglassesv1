package com.lang.y_esp8266_smartglasses;

import java.io.IOException;

import fi.iki.elonen.NanoHTTPD;

/*
* Example from http://jensklin.triangulum.uberspace.de/how-to-run-a-webserver-on-android/
* */

public class WebServer extends NanoHTTPD {

    public static final int PORT = 8080;

    String response = "Init...";

    public WebServer() throws IOException {
        super(PORT);
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @Override public Response serve(IHTTPSession session) {
        String uri = session.getUri();

        if (uri.equals("/")) {
            return newFixedLengthResponse(response);
        }
        return null;
    }
}
