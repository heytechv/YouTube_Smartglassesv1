package com.lang.y_esp8266_smartglasses;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    EditText etSend; Button bSend; CheckBox cbSendAuto;

    boolean isAuto = false;

    WebServer server = null;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSend = findViewById(R.id.et_SendText);
        bSend = findViewById(R.id.b_SendText);
        cbSendAuto = findViewById(R.id.cb_SendAuto);

        try {
            server = new WebServer();
            server.start();

            bSend.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    server.setResponse(etSend.getText().toString());
                    isAuto = false;
                    cbSendAuto.setChecked(false);
                }
            });

            cbSendAuto.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    isAuto = b;

                }
            });

        } catch (IOException e) {
            e.printStackTrace();
        }

        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                while (true) {
                    if (isAuto) {
                        Date date = Calendar.getInstance().getTime();

                        DateFormat format = new SimpleDateFormat("HH:mm");
                        String time = format.format(date);

                        server.setResponse(time);

                        try { Thread.sleep(500); } catch (Exception e) { e.printStackTrace(); }
                    }
                }
            }
        });
        t.setDaemon(true);
        t.start();

    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (server != null) server.stop();
    }
}
